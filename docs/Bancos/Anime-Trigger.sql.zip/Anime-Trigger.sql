-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 05, 2013 at 02:09 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Anime-Trigger`
--

-- --------------------------------------------------------

--
-- Table structure for table `aborda`
--

CREATE TABLE `aborda` (
  `tema_id` int(11) NOT NULL,
  `serie_id` int(11) NOT NULL,
  PRIMARY KEY (`tema_id`,`serie_id`),
  KEY `fk_animes_has_temas_temas1_idx` (`tema_id`),
  KEY `fk_aborda_series1_idx` (`serie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aborda`
--


-- --------------------------------------------------------

--
-- Table structure for table `acompanhamentos`
--

CREATE TABLE `acompanhamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `acompanhamentos`
--


-- --------------------------------------------------------

--
-- Table structure for table `acompanhamento_animes`
--

CREATE TABLE `acompanhamento_animes` (
  `animes_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `acompanhamento_id` int(11) NOT NULL,
  PRIMARY KEY (`animes_id`,`usuarios_id`),
  KEY `fk_animes_has_usuarios_usuarios1_idx` (`usuarios_id`),
  KEY `fk_acompanhamento_animes_acompanhamentos1_idx` (`acompanhamento_id`),
  KEY `fk_animes_has_usuarios_animes1_idx` (`animes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acompanhamento_animes`
--


-- --------------------------------------------------------

--
-- Table structure for table `acompanhamento_captulos`
--

CREATE TABLE `acompanhamento_captulos` (
  `usuario_id` int(11) NOT NULL,
  `captulo_id` int(11) NOT NULL,
  `acompanhamento_id` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id`,`captulo_id`),
  KEY `fk_usuarios_has_captulos_captulos1_idx` (`captulo_id`),
  KEY `fk_acompanhamento_captulos_acompanhamentos1_idx` (`acompanhamento_id`),
  KEY `fk_usuarios_has_captulos_usuarios1_idx` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acompanhamento_captulos`
--


-- --------------------------------------------------------

--
-- Table structure for table `acompanhamento_series`
--

CREATE TABLE `acompanhamento_series` (
  `series_id` int(11) NOT NULL,
  `usuarios_id` int(11) NOT NULL,
  `acompanhamento_id` int(11) NOT NULL,
  PRIMARY KEY (`series_id`,`usuarios_id`),
  KEY `fk_series_has_usuarios_usuarios1_idx` (`usuarios_id`),
  KEY `fk_acompanhamento_series_acompanhamentos1_idx` (`acompanhamento_id`),
  KEY `fk_series_has_usuarios_series1_idx` (`series_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acompanhamento_series`
--


-- --------------------------------------------------------

--
-- Table structure for table `animes`
--

CREATE TABLE `animes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `numero` int(11) NOT NULL DEFAULT '0',
  `apelido` varchar(255) DEFAULT NULL,
  `numeroDeEpisodios` int(11) DEFAULT NULL,
  `sinopse` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `serie_id` int(11) NOT NULL,
  `multimidia_id` int(11) NOT NULL,
  `idioma_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_animes_series1_idx` (`serie_id`),
  KEY `fk_animes_multimidia1_idx` (`multimidia_id`),
  KEY `fk_animes_idiomas1_idx` (`idioma_id`),
  KEY `fk_animes_status1_idx` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `animes`
--


-- --------------------------------------------------------

--
-- Table structure for table `animes_generos`
--

CREATE TABLE `animes_generos` (
  `anime_id` int(11) NOT NULL,
  `genero_id` int(11) NOT NULL,
  PRIMARY KEY (`anime_id`,`genero_id`),
  KEY `fk_animes_has_generos_generos1_idx` (`genero_id`),
  KEY `fk_animes_has_generos_animes1_idx` (`anime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `animes_generos`
--


-- --------------------------------------------------------

--
-- Table structure for table `autores`
--

CREATE TABLE `autores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `autores`
--


-- --------------------------------------------------------

--
-- Table structure for table `autoria_anime`
--

CREATE TABLE `autoria_anime` (
  `autor_id` int(11) NOT NULL,
  `anime_id` int(11) NOT NULL,
  PRIMARY KEY (`autor_id`,`anime_id`),
  KEY `fk_animes_has_autores_autores1_idx` (`autor_id`),
  KEY `fk_animes_has_autores_animes1_idx` (`anime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `autoria_anime`
--


-- --------------------------------------------------------

--
-- Table structure for table `autoria_serie`
--

CREATE TABLE `autoria_serie` (
  `autor_id` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  PRIMARY KEY (`autor_id`,`series_id`),
  KEY `fk_autores_has_series_series1_idx` (`series_id`),
  KEY `fk_autores_has_series_autores1_idx` (`autor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `autoria_serie`
--


-- --------------------------------------------------------

--
-- Table structure for table `compativel`
--

CREATE TABLE `compativel` (
  `qualidade_id` int(11) NOT NULL,
  `multimidia_id` int(11) NOT NULL,
  PRIMARY KEY (`qualidade_id`,`multimidia_id`),
  KEY `fk_qualidades_has_multimidias_multimidias1_idx` (`multimidia_id`),
  KEY `fk_qualidades_has_multimidias_qualidades1_idx` (`qualidade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compativel`
--


-- --------------------------------------------------------

--
-- Table structure for table `fansub`
--

CREATE TABLE `fansub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sigla` varchar(255) DEFAULT NULL,
  `slogan` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `sinopse` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fansub`
--


-- --------------------------------------------------------

--
-- Table structure for table `generos`
--

CREATE TABLE `generos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generos`
--


-- --------------------------------------------------------

--
-- Table structure for table `idiomas`
--

CREATE TABLE `idiomas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sigla` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `idiomas`
--


-- --------------------------------------------------------

--
-- Table structure for table `informacoes`
--

CREATE TABLE `informacoes` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `conteudo` longtext NOT NULL,
  `topico_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_informacoes_topico1_idx` (`topico_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informacoes`
--


-- --------------------------------------------------------

--
-- Table structure for table `informacoes_de_sitema`
--

CREATE TABLE `informacoes_de_sitema` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `informacao` longtext NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informacoes_de_sitema`
--


-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `captulo_id` int(11) NOT NULL,
  `qualidade_id` int(11) NOT NULL,
  `servidor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_links_captulos_idx` (`captulo_id`),
  KEY `fk_links_qualidades1_idx` (`qualidade_id`),
  KEY `fk_links_servidores1_idx` (`servidor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `links`
--


-- --------------------------------------------------------

--
-- Table structure for table `multimidias`
--

CREATE TABLE `multimidias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sigla` varchar(255) DEFAULT NULL,
  `unidade` varchar(255) DEFAULT 'captulo',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `multimidias`
--


-- --------------------------------------------------------

--
-- Table structure for table `qualidades`
--

CREATE TABLE `qualidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sigla` varchar(255) DEFAULT NULL,
  `nota` int(11) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `qualidades`
--


-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE `series` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `sinopse` longtext,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_series_status1_idx` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `series`
--


-- --------------------------------------------------------

--
-- Table structure for table `series_generos`
--

CREATE TABLE `series_generos` (
  `series_id` int(11) NOT NULL,
  `generos_id` int(11) NOT NULL,
  PRIMARY KEY (`series_id`,`generos_id`),
  KEY `fk_series_has_generos_generos1_idx` (`generos_id`),
  KEY `fk_series_has_generos_series1_idx` (`series_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `series_generos`
--


-- --------------------------------------------------------

--
-- Table structure for table `servidores`
--

CREATE TABLE `servidores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `habilitado` tinyint(1) NOT NULL DEFAULT '1',
  `usuario` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `servidores`
--


-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `created` varchar(255) DEFAULT NULL,
  `modified` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `status`
--


-- --------------------------------------------------------

--
-- Table structure for table `temas`
--

CREATE TABLE `temas` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temas`
--


-- --------------------------------------------------------

--
-- Table structure for table `topicos`
--

CREATE TABLE `topicos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `series_id` int(11) NOT NULL,
  `idioma_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_topico_series1_idx` (`series_id`),
  KEY `fk_topico_idiomas1_idx` (`idioma_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topicos`
--


-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `nick` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `usuario_tipo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_usuarios_tipos_usuarios1_idx` (`usuario_tipo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--


-- --------------------------------------------------------

--
-- Table structure for table `usuarios_idiomas`
--

CREATE TABLE `usuarios_idiomas` (
  `usuario_id` int(11) NOT NULL,
  `idioma_id` int(11) NOT NULL,
  `numero` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usuario_id`,`idioma_id`),
  KEY `fk_usuarios_has_idiomas_idiomas1_idx` (`idioma_id`),
  KEY `fk_usuarios_has_idiomas_usuarios1_idx` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios_idiomas`
--


-- --------------------------------------------------------

--
-- Table structure for table `usuario_tipos`
--

CREATE TABLE `usuario_tipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `permissao` int(11) NOT NULL DEFAULT '10',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `usuario_tipos`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `aborda`
--
ALTER TABLE `aborda`
  ADD CONSTRAINT `fk_aborda_series1` FOREIGN KEY (`serie_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_has_temas_temas1` FOREIGN KEY (`tema_id`) REFERENCES `temas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `acompanhamento_animes`
--
ALTER TABLE `acompanhamento_animes`
  ADD CONSTRAINT `fk_acompanhamento_animes_acompanhamentos1` FOREIGN KEY (`acompanhamento_id`) REFERENCES `acompanhamentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_has_usuarios_animes1` FOREIGN KEY (`animes_id`) REFERENCES `animes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_has_usuarios_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `acompanhamento_captulos`
--
ALTER TABLE `acompanhamento_captulos`
  ADD CONSTRAINT `fk_acompanhamento_captulos_acompanhamentos1` FOREIGN KEY (`acompanhamento_id`) REFERENCES `acompanhamentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuarios_has_captulos_captulos1` FOREIGN KEY (`captulo_id`) REFERENCES `captiulos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuarios_has_captulos_usuarios1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `acompanhamento_series`
--
ALTER TABLE `acompanhamento_series`
  ADD CONSTRAINT `fk_acompanhamento_series_acompanhamentos1` FOREIGN KEY (`acompanhamento_id`) REFERENCES `acompanhamentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_series_has_usuarios_series1` FOREIGN KEY (`series_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_series_has_usuarios_usuarios1` FOREIGN KEY (`usuarios_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `animes`
--
ALTER TABLE `animes`
  ADD CONSTRAINT `fk_animes_fansub1` FOREIGN KEY (`fansub_id`) REFERENCES `fansub` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_idiomas1` FOREIGN KEY (`idioma_id`) REFERENCES `idiomas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_multimidia1` FOREIGN KEY (`multimidia_id`) REFERENCES `multimidias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_series1` FOREIGN KEY (`serie_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `animes_generos`
--
ALTER TABLE `animes_generos`
  ADD CONSTRAINT `fk_animes_has_generos_animes1` FOREIGN KEY (`anime_id`) REFERENCES `animes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_has_generos_generos1` FOREIGN KEY (`genero_id`) REFERENCES `generos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `autoria_anime`
--
ALTER TABLE `autoria_anime`
  ADD CONSTRAINT `fk_animes_has_autores_animes1` FOREIGN KEY (`anime_id`) REFERENCES `animes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_animes_has_autores_autores1` FOREIGN KEY (`autor_id`) REFERENCES `autores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `autoria_serie`
--
ALTER TABLE `autoria_serie`
  ADD CONSTRAINT `fk_autores_has_series_autores1` FOREIGN KEY (`autor_id`) REFERENCES `autores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_autores_has_series_series1` FOREIGN KEY (`series_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `compativel`
--
ALTER TABLE `compativel`
  ADD CONSTRAINT `fk_qualidades_has_multimidias_multimidias1` FOREIGN KEY (`multimidia_id`) REFERENCES `multimidias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_qualidades_has_multimidias_qualidades1` FOREIGN KEY (`qualidade_id`) REFERENCES `qualidades` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `informacoes`
--
ALTER TABLE `informacoes`
  ADD CONSTRAINT `fk_informacoes_topico1` FOREIGN KEY (`topico_id`) REFERENCES `topicos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `links`
--
ALTER TABLE `links`
  ADD CONSTRAINT `fk_links_captulos` FOREIGN KEY (`captulo_id`) REFERENCES `captiulos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_links_qualidades1` FOREIGN KEY (`qualidade_id`) REFERENCES `qualidades` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_links_servidores1` FOREIGN KEY (`servidor_id`) REFERENCES `servidores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `series`
--
ALTER TABLE `series`
  ADD CONSTRAINT `fk_series_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `series_generos`
--
ALTER TABLE `series_generos`
  ADD CONSTRAINT `fk_series_has_generos_generos1` FOREIGN KEY (`generos_id`) REFERENCES `generos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_series_has_generos_series1` FOREIGN KEY (`series_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `topicos`
--
ALTER TABLE `topicos`
  ADD CONSTRAINT `fk_topico_idiomas1` FOREIGN KEY (`idioma_id`) REFERENCES `idiomas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_topico_series1` FOREIGN KEY (`series_id`) REFERENCES `series` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuarios_tipos_usuarios1` FOREIGN KEY (`usuario_tipo_id`) REFERENCES `usuario_tipos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `usuarios_idiomas`
--
ALTER TABLE `usuarios_idiomas`
  ADD CONSTRAINT `fk_usuarios_has_idiomas_idiomas1` FOREIGN KEY (`idioma_id`) REFERENCES `idiomas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuarios_has_idiomas_usuarios1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
